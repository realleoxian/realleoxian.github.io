package de.leoxian.moonlightcore.neoforge.common.registry;

import de.leoxian.moonlightcore.common.registry.RegistryBuilder;
import net.minecraft.core.Registry;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.registries.NewRegistryEvent;

import java.util.*;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import java.util.function.Supplier;

@EventBusSubscriber
public class NeoforgeRegistryBuilder<R> implements RegistryBuilder<R> {
    private static final List<Consumer<NewRegistryEvent>> REGISTRY_CALLBACKS = new ArrayList<>();

    @SubscribeEvent
    public static void onNewRegistries(NewRegistryEvent event) {
        REGISTRY_CALLBACKS.forEach(callback -> callback.accept(event));
    }

    private final ResourceKey<Registry<R>> registryKey;
    private boolean sync = false;
    private Identifier defaultId = null;

    public NeoforgeRegistryBuilder(ResourceKey<Registry<R>> registryKey) {
        this.registryKey = registryKey;
    }

    @Override
    public RegistryBuilder<R> sync(boolean sync) {
        this.sync = sync;
        return this;
    }

    @Override
    public RegistryBuilder<R> defaultId(Identifier id) {
        this.defaultId = id;
        return this;
    }

    @Override
    public Supplier<Registry<R>> build() {
        AtomicReference<Registry<R>> registryRef = new AtomicReference<>();
        REGISTRY_CALLBACKS.add(event -> {
            net.neoforged.neoforge.registries.RegistryBuilder<R> neoBuilder = new net.neoforged.neoforge.registries.RegistryBuilder<>(this.registryKey);
            neoBuilder.sync(this.sync);
            neoBuilder.defaultKey(this.defaultId);

            Registry<R> created = event.create(neoBuilder);
            registryRef.set(created);
        });

        return () -> {
            Registry<R> registry = registryRef.get();
            if (registry == null) {
                throw new NullPointerException("Attempted to get registry '" + this.registryKey + "' before was built");
            }
            return registry;
        };
    }
}
