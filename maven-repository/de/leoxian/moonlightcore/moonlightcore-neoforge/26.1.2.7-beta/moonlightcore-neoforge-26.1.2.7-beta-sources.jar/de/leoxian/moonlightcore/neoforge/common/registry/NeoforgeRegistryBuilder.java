package de.leoxian.moonlightcore.neoforge.common.registry;

import de.leoxian.moonlightcore.common.registry.RegistryBuilder;
import net.minecraft.core.Registry;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.registries.NewRegistryEvent;

import java.util.*;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.function.Consumer;

@EventBusSubscriber
public class NeoforgeRegistryBuilder<R> implements RegistryBuilder<R> {
    private static final List<Consumer<NewRegistryEvent>> REGISTRY_CALLBACKS = new ArrayList<>();

    @SubscribeEvent
    public static void onNewRegistries(NewRegistryEvent event) {
        REGISTRY_CALLBACKS.forEach(callback -> callback.accept(event));
    }

    private final ResourceKey<Registry<R>> registryKey;
    private boolean sync = false;
    private Identifier defaultId = null;

    public NeoforgeRegistryBuilder(ResourceKey<Registry<R>> registryKey) {
        this.registryKey = registryKey;
    }

    @Override
    public RegistryBuilder<R> sync(boolean sync) {
        this.sync = sync;
        return this;
    }

    @Override
    public RegistryBuilder<R> defaultId(Identifier id) {
        this.defaultId = id;
        return this;
    }

    @Override
    public Registry<R> build() {
        net.neoforged.neoforge.registries.RegistryBuilder<R> builder = new net.neoforged.neoforge.registries.RegistryBuilder<>(this.registryKey);
        if (this.sync) builder = builder.sync(true);
        if (this.defaultId != null) builder = builder.defaultKey(this.defaultId);

        Registry<R> registry = builder.create();
        REGISTRY_CALLBACKS.add(e -> e.register(registry));
        return registry;
    }
}
