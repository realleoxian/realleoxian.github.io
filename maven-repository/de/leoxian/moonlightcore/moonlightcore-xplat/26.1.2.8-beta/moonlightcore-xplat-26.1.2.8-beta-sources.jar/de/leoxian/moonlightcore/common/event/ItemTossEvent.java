package de.leoxian.moonlightcore.common.event;

import de.leoxian.moonlightcore.common.event.base.Event;
import de.leoxian.moonlightcore.common.event.base.EventResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;

@FunctionalInterface
public interface ItemTossEvent {
	Event<ItemTossEvent> EVENT = Event.create(ItemTossEvent.class, listeners -> (player, entity) -> {
	var result = EventResult.TRUE;
		for (final var listener : listeners) {
		result = listener.onItemToss(player, entity);
		if (result.cancelFurtherEventProcessing()) {
			break;
		}
		}
		return result;
	});

	EventResult onItemToss(LivingEntity player, ItemEntity entity);
}
