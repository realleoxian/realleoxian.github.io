package de.leoxian.moonlightcore.internal.common.config.file;

import de.leoxian.moonlightcore.common.config.Config;
import de.leoxian.moonlightcore.common.config.ConfigSchema;
import de.leoxian.moonlightcore.common.config.ConfigValue;
import de.leoxian.moonlightcore.common.config.file.LoadedConfig;
import de.leoxian.moonlightcore.common.config.schema.ConfigKey;

import java.io.IOException;
import java.nio.file.Files;
import java.util.*;
import java.util.regex.Pattern;

public final class LoadedConfigImpl implements LoadedConfig {
	private static final Pattern COMMENT_REGEX = Pattern.compile("#.*");
	private static final Pattern SCHEMA_REGEX = Pattern.compile("\\[(?<key>.*)]$");
	private static final Pattern VALUE_REGEX = Pattern.compile("\\s*(?<key>.*)\\s*=\\s*(?<value>.*)\\s*$");

	public static Optional<LoadedConfig> load(Config<?> config) throws IOException {
		if (!Files.exists(config.filePath())) return Optional.empty();
		List<String> content = Files.readAllLines(config.filePath());

		Map<ConfigKey, Object> loadedData = new HashMap<>();
		var currentSchema = config.schema();

		for (final var line : content) {
			if (line.isEmpty() || COMMENT_REGEX.matcher(line).matches()) continue;

			var valueMatcher = VALUE_REGEX.matcher(line);
			if (valueMatcher.matches()) {
				var key = new ConfigKey(valueMatcher.group("key"));
				var configValue = resolveConfigValue(currentSchema, config.schema(), key);

				if (configValue == null) {
					throw new IllegalStateException("Expected a valid config value, got: " + key);
				}

				final ConfigValue<?> value = configValue;
				value.type().readFromString(valueMatcher.group("value"))
						.ifSuccess((t) -> loadedData.put(value.key(), t))
						.ifError(errors -> {
							RuntimeException errorsException = new RuntimeException("Found unexpected errors parsing config value: " + value.key());
							for (final var error : errors) errorsException.addSuppressed(new RuntimeException(error));
							errorsException.printStackTrace();
							loadedData.put(value.key(), value.defaultValue());
						});
				continue;
			}

			var schemaMatcher = SCHEMA_REGEX.matcher(line);
			if (schemaMatcher.matches()) {
				var key = new ConfigKey(schemaMatcher.group("key"));
				var targetSchema = findSchemaPath(config.schema(), key, key.getComponentsCount());
				if (targetSchema == null) {
					throw new IllegalStateException("Expected a valid config schema path, instead got invalid schema on path " + key);
				}
				currentSchema = targetSchema;
			}
		}
		return Optional.of(new LoadedConfigImpl(loadedData));
	}

	private static ConfigSchema findSchemaPath(ConfigSchema root, ConfigKey key, int length) {
		var target = root;
		for (int i = 0; i < length; i++) {
			target = target.getSection(key.get(i));
			if (target == null) return null;
		}
		return target;
	}

	private static ConfigValue<?> resolveConfigValue(ConfigSchema currentSchema, ConfigSchema rootSchema, ConfigKey key) {
		int count = key.getComponentsCount();
		if (count == 1) {
			var value = currentSchema.getValue(key.lastComponent());
			return value != null ? value : rootSchema.getValue(key.lastComponent());
		}

		var target = findSchemaPath(currentSchema, key, count - 1);
		if (target != null) {
			var value = target.getValue(key.lastComponent());
			if (value != null) return value;
		}

		target = findSchemaPath(rootSchema, key, count - 1);
		return target != null ? target.getValue(key.lastComponent()) : null;
	}

	private final Map<ConfigKey, Object> data;

	public LoadedConfigImpl(Map<ConfigKey, Object> data) {
		this.data = data;
	}

	public LoadedConfigImpl() {
		this.data = new HashMap<>();
	}

	@Override
	@SuppressWarnings("unchecked")
	public <T> T getRaw(ConfigValue<T> configValue) {
		var ret = this.data.get(configValue.key());
		return ret == null ? configValue.defaultValue() : (T) ret;
	}

	@Override
    public <T> void setRaw(ConfigValue<T> configValue, T newValue) {
		this.data.put(configValue.key(), newValue);
	}
}