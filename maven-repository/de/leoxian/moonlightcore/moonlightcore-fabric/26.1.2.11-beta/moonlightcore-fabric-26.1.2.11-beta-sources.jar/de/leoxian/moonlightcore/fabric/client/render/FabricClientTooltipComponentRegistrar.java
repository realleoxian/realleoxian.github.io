package de.leoxian.moonlightcore.fabric.client.render;

import de.leoxian.moonlightcore.client.render.ClientTooltipComponentRegistrar;
import net.fabricmc.fabric.api.client.rendering.v1.ClientTooltipComponentCallback;
import net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipComponent;
import net.minecraft.world.inventory.tooltip.TooltipComponent;

import java.util.function.Function;

public enum FabricClientTooltipComponentRegistrar implements ClientTooltipComponentRegistrar {
	INSTANCE
	;

	@Override
	public <T extends TooltipComponent> void register(Class<T> type, Function<? super T, ? extends ClientTooltipComponent> factory) {
		ClientTooltipComponentCallback.EVENT.register(data -> {
			if (data.getClass() == type) {
				return factory.apply(type.cast(data));
			}
			return null;
		});
	}
}
