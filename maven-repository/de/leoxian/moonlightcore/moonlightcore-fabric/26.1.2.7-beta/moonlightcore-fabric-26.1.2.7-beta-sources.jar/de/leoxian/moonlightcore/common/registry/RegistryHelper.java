package de.leoxian.moonlightcore.common.registry;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import com.mojang.logging.LogUtils;
import de.leoxian.moonlightcore.common.platform.XplatAbstraction;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import org.jetbrains.annotations.ApiStatus;
import org.slf4j.Logger;

import java.util.function.BiConsumer;

public class RegistryHelper {
    private static final Logger LOGGER = LogUtils.getLogger();

    public interface Registrar<R> {
        void registerAll(BiConsumer<String, R> output);
    }

    public static RegistryHelper create(final String modId) {
        return new RegistryHelper(modId);
    }

    private final Multimap<ResourceKey<? extends Registry<?>>, Registrar<?>> registrars = ArrayListMultimap.create();
    private final String modId;

    private RegistryHelper(String modId) {
        this.modId = modId;
    }

    @SuppressWarnings("unchecked")
    public void setup() {
        this.registrars.forEach((registry, registrar) ->
                setupRegistry((ResourceKey<? extends Registry<Object>>) registry, (Registrar<Object>) registrar));
    }

    public <R> void add(ResourceKey<? extends Registry<R>> registryKey, Registrar<R> registrar) {
        this.registrars.put(registryKey, registrar);
    }

    @ApiStatus.Internal
    @SuppressWarnings("unchecked")
    private <R> void setupRegistry(ResourceKey<? extends Registry<R>> registryKey, Registrar<R> registrar) {
        Registry<R> registry = (Registry<R>) BuiltInRegistries.REGISTRY.getValue(registryKey.identifier());
        if (registry == null) {
            LOGGER.warn("Registry not found: {}. Skipping registration", registryKey);
            return;
        }

        registrar.registerAll((name, value) ->
                XplatAbstraction.INSTANCE.register(registry, Identifier.fromNamespaceAndPath(this.modId, name), () -> value));
    }
}
